import React, { useEffect } from "react";
import "./secSection.scss";
export default function SecSection() {
  return (
    <div className="sec-section-relative-div">
      <div className="secsection-banner-image">
        <div className="sec-image-header-relative"></div>
      </div>
      <div className="dot-image-style"></div>
    </div>
  );
}
